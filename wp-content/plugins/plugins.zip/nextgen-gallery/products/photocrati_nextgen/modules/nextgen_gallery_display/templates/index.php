<h1>Default Gallery Type Template</h1>
<p>
	This is the default gallery type template, located in:<br/>
	<b><?php esc_html_e(__FILE__)?></b>.
</p>
<p>
	If you're seeing this, it's because the gallery type you selected has not
	provided a template of it's own.
</p>